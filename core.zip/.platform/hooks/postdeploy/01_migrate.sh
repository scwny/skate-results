#!/bin/bash
# Runs every time EB successfully deploys a new application version.
#source /var/app/venv/*/bin/activate        # activates the virtual-env EB created
#cd /var/app/current                         # the app code directory
#python manage.py migrate --noinput
